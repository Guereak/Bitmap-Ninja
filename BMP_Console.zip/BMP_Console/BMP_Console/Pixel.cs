﻿namespace BMP_Console
{
    class Pixel
    {
        //Can this be made into a struct?
        public byte red;
        public byte green;
        public byte blue;

        public Pixel(byte red, byte green, byte blue)
        {
            this.red = red;
            this.green = green;
            this.blue = blue;
        }


    }
}
